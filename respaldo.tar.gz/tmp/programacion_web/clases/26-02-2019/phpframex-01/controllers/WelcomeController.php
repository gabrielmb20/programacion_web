<?php
  class WelcomeController {
    public function index() {
      echo 'Hello, World!';
    }
  }
?>
