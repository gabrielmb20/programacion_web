<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>{{title}}</title>

<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="/css/normalize.css">
<link rel="stylesheet" href="/css/skeleton.css">
</head>
<body>
 <div class="container">
  <div class="row">
   <div class="eleven column" style="margin-top: 10%">
     <h2>{{title}}</h2>
     <table><thead>
      <tr><th>ID</th><th>Name</th><th>Direccion</th>
          <th>Carrera</th><th>Email</th><th>Phone</th></tr>
      </thead><tbody>
      {{#students}}
      <tr>
      <td>{{id}}</td>
      <td><a href="student/{{id}}"/>{{name}}</a></td>
      <td>{{direccion}}</td>
      <td>{{carrera}}</td>
      <td>{{email}}</td>
      <td>{{phone}}</td></tr>
      {{/students}}</tbody>
     </table>
    </div>
   </div>
 </div>
</body>
