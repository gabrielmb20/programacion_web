<?php
    Route::resource('student', 'StudentController'); 
    Route::resource('student2', 'StudentController2'); 

    Route::dispatch();
?>
