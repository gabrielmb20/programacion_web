<?php
  require_once('./models/Student.php');

  class StudentController extends Controller {

    public function index() {  
      return view('student/index',
       ['students'=>Student::all(),
        'title'=>'Students List']);
    }

    public function show($id) {
      $prof = Student::find($id);
      return view('student/show',
        ['student'=>$prof,
         'title'=>'Student Detail']);
    }
  }
?>
