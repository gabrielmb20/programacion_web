<?php
  require_once('./models/Student.php');

  class StudentController2 extends Controller {

    public function index() {  
      return view('student/index2',
       ['students'=>Student::all(),
        'title'=>'Students List']);
    }

    public function show($id) {
      $prof = Student::find($id);
      return view('student/show2',
        ['student'=>$prof,
         'title'=>'Student Detail']);
    }
  }
?>
